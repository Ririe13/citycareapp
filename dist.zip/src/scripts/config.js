export const ACCESS_TOKEN_KEY = 'accessToken';

export const BASE_URL = 'https://citycare-api.dicoding.dev/v1';

export const MAP_SERVICE_API_KEY = 'YOUR_KEY';


